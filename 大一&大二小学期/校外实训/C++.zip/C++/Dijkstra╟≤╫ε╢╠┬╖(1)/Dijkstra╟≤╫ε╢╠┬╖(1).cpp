#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

const int maxn=505;
int g[maxn][maxn];
int dist[maxn];
int n,m;
bool sta[maxn];

int dijkstra()
{
	dist[1]=0;
	for(int i=1;i<=n;i++)
    {
        int t=-1;
        for(int j=1;j<=n;j++)
        {
            if(!sta[j]&&(t==-1||dist[t]>dist[j]))
                t=j;
		}
		for(int j=1;j<=n;j++)
			dist[j]=min(dist[t]+g[t][j],dist[j]);
		sta[t]=true;
	}
	if(dist[n]==0x3f3f3f3f) return -1;
	return dist[n];
}

int main()
{
    cin>>n>>m;
    memset(dist,0x3f,sizeof(dist));
    memset(g,0x3f,sizeof g);
    while (m--)
    {
        int a,b,k;
        cin>>a>>b>>k;
        g[a][b]=min(g[a][b],k);
    }
    cout<<dijkstra();
    return 0;
}
