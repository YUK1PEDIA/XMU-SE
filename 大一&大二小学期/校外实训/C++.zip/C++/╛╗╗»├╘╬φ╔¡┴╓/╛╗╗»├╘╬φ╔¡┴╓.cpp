# include <iostream>
# include <cstring>
using namespace std;
int cnt=0,W,H;
int clean[21][21]={0};
char matrix[21][21];

void fps(int m,int n)
{
	if(m>=H||n>=W||m<0||n<0||matrix[m][n]=='#'||clean[m][n])
		return;
	else
	{
		clean[m][n]=1;
		cnt++;
		fps(m-1,n);
		fps(m+1,n);
		fps(m,n-1);
		fps(m,n+1);
	}
}

int main()
{
	cin>>W>>H;
	while(W||H)
	{
		int m,n;
		for(int i=0;i<H;i++)
		{
			for(int j=0;j<W;j++)
			{
				cin>> matrix[i][j];
				if(matrix[i][j]=='@')
				{
					m=i;
					n=j;

				}
			}
		}
		cnt=0;
		fps(m,n);
		cout<<cnt<<endl;
		memset(clean,0,sizeof(clean));
		cin>>W>>H;
	}
	return 0;
}
