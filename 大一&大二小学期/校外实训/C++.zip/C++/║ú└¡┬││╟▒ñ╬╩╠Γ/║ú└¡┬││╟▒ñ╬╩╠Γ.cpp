#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>
using namespace std;
#define For(a,begin,end) for(register int a = begin; a <= end; ++a)

int row,column;
const int nroom = 60;
int rooms[nroom][nroom];
int color[nroom][nroom];
int maxroomarea = 0,roomno=0;
int roomarea;

bool isLeftOpen(int wall,int mask=1)
{
    return (wall & mask)==0;
}

bool isUpOpen(int wall,int mask=2)
{
    return (wall & mask)==0;
}

bool isRightOpen(int wall,int mask=4)
{
    return (wall & mask)==0;
}

bool isDownOpen(int wall,int mask=8)
{
    return (wall & mask)==0;
}

int dfs(int i,int k)
{
    if(color[i][k]) return 0;
    ++roomarea;
    color[i][k] = roomno;
    if(isLeftOpen(rooms[i][k]))  dfs(i,k-1);
    if(isUpOpen(rooms[i][k]))  dfs(i-1,k);
    if(isRightOpen(rooms[i][k]))  dfs(i,k+1);
    if(isDownOpen(rooms[i][k]))  dfs(i+1,k);
}
int main()
{
    cin>>row>>column;
    For(i,1,row) For(j,1,column) cin>>rooms[i][j];
    memset(color,0,sizeof(color));
    For(i,1,row) For(j,1,column)
    {
        if(!color[i][j])
        {
            ++roomno;
            roomarea=0;
            dfs(i,j);
            maxroomarea = max(maxroomarea,roomarea);
        }
    }
    cout << roomno << endl;
    cout<<maxroomarea<<endl;
}
