#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

constexpr int N=16,M=N*N;
char str[N][N+1];
char str2[M+1][N][N+1];
int ones[1<<N],map[1<<N];
int state[N][N];
int state2[M+1][N][N],state3[M+1][N][N];

inline constexpr int lowbit(int x)
{
	return x&-x;
}

void init(int x,int y,int c)
{
	str[x][y]=c+'A';
	for(int i=0;i<N;i++)
	{
		state[x][i]&=~(1<<c);
		state[i][y]&=~(1<<c);
	}
	int sx=x/4*4,sy=y/4*4;
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			state[sx+i][sy+j]&=~(1<<c);
	state[x][y]=1<<c;
}

bool dfs(int cnt)
{
	if(!cnt) return true;
	int kcnt=cnt;
	memcpy(str2[kcnt],str,sizeof str);
	memcpy(state2[kcnt],state,sizeof state);
	for(int i=0;i<N;i++)
	{
		for(int j=0;j<N;j++)
		{
			if(str[i][j]=='-')
			{
				int s=state[i][j];
				if(!s)
				{
					memcpy(str,str2[kcnt],sizeof str);
					memcpy(state,state2[kcnt],sizeof state);
					return false;
				}
				if(ones[s]==1)
				{
					init(i,j,map[s]);
					cnt--;
				}
			}
		}
	}
	for(int i=0;i<N;i++)
	{
		int sor=0,sand=(1<<N)-1;
		int drawn=0;
		for(int j=0;j<N;j++)
		{
			int s=state[i][j];
			sand&=~(s&sor);
			sor|=s;
			if(str[i][j]!='-') drawn|=s;
		}
		if(sor!=(1<<N)-1)
		{
			memcpy(str,str2[kcnt],sizeof str);
			memcpy(state,state2[kcnt],sizeof state);
			return false;
		}
		for(int j=sand;j;j-=lowbit(j))
		{
			int t=lowbit(j);
			if(!(drawn&t))
			{
				for(int k=0;k<N;k++)
				{
					if(state[i][k]&t)
					{
						init(i,k,map[t]);
						cnt--;
						break;
					}
				}
			}
		}
	}
	for(int i=0;i<N;i++)
	{
		int sor=0,sand=(1<<N)-1;
		int drawn=0;
		for(int j=0;j<N;j++)
		{
			int s=state[j][i];
			sand&=~(s&sor);
			sor|=s;
			if(str[j][i]!='-') drawn|=s;
		}
		if(sor!=(1<<N)-1)
		{
			memcpy(str,str2[kcnt],sizeof str);
			memcpy(state,state2[kcnt],sizeof state);
			return false;
		}
		for(int j=sand;j;j-=lowbit(j))
		{
			int t=lowbit(j);
			if(!(drawn&t))
			{
				for(int k=0;k<N;k++)
				{
					if(state[k][i]&t)
					{
						init(k,i,map[t]);
						cnt--;
						break;
					}
				}
			}
		}
	}
	for(int i=0;i<N;i++)
	{
		int sor=0,sand=(1<<N)-1;
		int drawn=0;
		for(int j=0;j<N;j++)
		{
			int sx=i/4*4,sy=i%4*4;
			int dx=j/4,dy=j%4;
			int s=state[sx+dx][sy+dy];
			sand&=~(s&sor);
			sor|=s;
			if(str[sx+dx][sy+dy]!='-') drawn|=s;
		}
		if(sor!=(1<<N)-1)
		{
			memcpy(str,str2[kcnt],sizeof str);
			memcpy(state,state2[kcnt],sizeof state);
			return false;
		}
		for(int j=sand;j;j-=lowbit(j))
		{
			int t=lowbit(j);
			if(!(drawn&t))
			{
				for(int k=0;k<N;k++)
				{
					int sx=i/4*4,sy=i%4*4;
					int dx=k/4,dy=k%4;
					if(state[sx+dx][sy+dy]&t)
					{
						init(sx+dx,sy+dy,map[t]);
						cnt--;
						break;
					}
				}
			}
		}
	}
	if(!cnt) return true;
	int x,y,s=20;
	for(int i=0;i<N;i++)
	{
		for(int j=0;j<N;j++)
		{
			if(str[i][j]=='-'&&ones[state[i][j]]<s)
			{
				s=ones[state[i][j]];
				x=i,y=j;
			}
		}
	}
	memcpy(state3[kcnt],state,sizeof state);
	for(int i=state[x][y];i;i-=lowbit(i))
	{
		memcpy(state,state3[kcnt],sizeof state);
		init(x,y,map[lowbit(i)]);
		if(dfs(cnt-1)) return true;
	}
	memcpy(state,state2[kcnt],sizeof state);
	memcpy(str,str2[kcnt],sizeof str);
	return false;
}

int main()
{
	for(int i=0;i<N;i++) map[1<<i]=i;
	for(int i=0;i<1<<N;i++)
	{
		for(int j=i;j;j-=lowbit(j))
			ones[i]++;
	}
	for(auto&i:str) cin>>i;
	for(auto&i:state)
		for(int&j:i)
			j=(1<<N)-1;
	int cnt=0;
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			if(str[i][j]!='-')
				init(i,j,str[i][j]-'A');
			else cnt++;
	dfs(cnt);
	for(auto&i:str) cout<<i<<endl;
	cout<<endl;
	return 0;
}
