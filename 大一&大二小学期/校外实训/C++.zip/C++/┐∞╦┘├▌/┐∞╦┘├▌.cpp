#include<iostream>
using namespace std;
#define ll long long

ll qsm(ll a,ll b,ll p)
{
    if(b==0)
        return 1;
    if(b==1)
        return a%p;
    ll res=qsm(a,b>>1,p);
    if(b%2==0)
        return res*res%p;
    else
        return(((res*res)%p)*a)%p;
}

int main()
{
    int n;
    cin>>n;
    while(n--)
    {
        int a,b,p;
        cin>>a>>b>>p;
        cout<<qsm(a,b,p)<<endl;
    }
    return 0;
}
