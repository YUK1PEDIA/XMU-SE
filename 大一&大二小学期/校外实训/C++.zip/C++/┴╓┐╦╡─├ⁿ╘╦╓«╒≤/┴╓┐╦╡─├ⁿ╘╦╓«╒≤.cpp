# include <iostream>
using namespace std;

int fates[70][70];

bool check(int i,int j)
{
	if(fates[i][j]==0)
		return true;
	else
		return false;
}

long long fps(int i,int j,int n)
{
	if(n==0)
		return 1;
	else
	{
		long long sum=0;
		fates[i][j]=1;
		if(check(i,j-1)) sum+=fps(i,j-1,n-1);
		if(check(i,j+1)) sum+=fps(i,j+1,n-1);
		if(check(i+1,j)) sum+=fps(i+1,j,n-1);
		fates[i][j]=0;
		return sum;
	}
}

int main()
{
	int n;
	cin>>n;
	cout<<fps(0,35,n)<<endl;
	return 0;
}
