#include<iostream>
#include<cmath>
using namespace std;

int main()
{
	int a,m,n;
	cin>>a>>m>>n;
	int count=0;
	for(int i=0;i<m;i++)
    {
		for(int j=0;j<n;j++)
		{
			if(i%10+i/10+j%10+j/10<=a)
				count++;
		}
	}
	cout<<count<<endl;
	return 0;
}
