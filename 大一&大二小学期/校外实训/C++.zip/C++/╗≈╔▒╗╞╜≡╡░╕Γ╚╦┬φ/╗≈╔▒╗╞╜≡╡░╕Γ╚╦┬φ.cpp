#include<bits/stdc++.h>
using namespace std;
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define _(d) while(d(isdigit(ch=getchar())))

template<class T>void g(T&t){T x,f=1;char ch;_(!)ch=='-'?f=-1:f;x=ch-48;_()x=x*10+ch-48;t=f*x;}
const int N = 50, inf = 1e8;
int w, h, m, ans, lim, res;
int f[N][N][N];

int main()
{
    while(23333)
    {
        g(w),g(h),g(m);
        if(w==0&&h==0&&m==0) break;
        memset(f,0x3f,sizeof(f));
        rep(i,1,w)
        {
            rep(j, 1, h)
            {
                rep(k, 0, m-1)
                {
                    if(k == 0)
                        f[i][j][k] =i * j;
                    else if(i * j < k + 1)
                        f[i][j][k] = inf;
                    else
                    {
                        rep(r, 1, i - 1)
                        {
                            rep(cnt, 0, k - 1)
                                f[i][j][k] = min(f[i][j][k], max(f[r][j][cnt], f[i - r][j][k - cnt - 1]));
                        }
                        rep(c, 1, j - 1)
                        {
                            rep(cnt, 0, k - 1)
                                f[i][j][k] = min(f[i][j][k], max(f[i][c][cnt], f[i][j - c][k - cnt - 1]));
                        }
                    }
                }
            }
        }
        printf("%d\n",f[w][h][m-1]);
    }
    return 0;
}
