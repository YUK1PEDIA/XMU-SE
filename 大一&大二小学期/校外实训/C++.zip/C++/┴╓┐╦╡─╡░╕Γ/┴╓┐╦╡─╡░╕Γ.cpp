#include<algorithm>
#include<cmath>
#include<iostream>
using namespace std;

const double PI=3.1415926535898;
double cakes[10010];
const double eps=1e-6;
int N,F;

bool Check(double x)
{
    if(x<eps) return true;
    int cnt=0;
    for(int i=0;i<N;i++)
    {
        int pieces=cakes[i]/x;
        cnt+=pieces;
        if(cnt>=F) return true;
    }
    return false;
}

double bsearch_d1(double l,double r)
{
    while (r-l>eps)
    {
        double mid=(l+r)/2;
        if(Check(mid))
        l=mid;
        else r=mid;

    }
    return l;
}

int main(){
    ios::sync_with_stdio(false);
    cin>>N>>F;
    F++;
    int a;
    double maxCake=0;
    for (int i=0;i<N;++i)
    {
        cin>>a;
        cakes[i]=(double)a*a;
        maxCake=max(maxCake,cakes[i]);
    }
    double l=0,r=maxCake;
    double res=bsearch_d1(l,r);
    printf("%.3lf\n",res*PI);
    return 0;
}
