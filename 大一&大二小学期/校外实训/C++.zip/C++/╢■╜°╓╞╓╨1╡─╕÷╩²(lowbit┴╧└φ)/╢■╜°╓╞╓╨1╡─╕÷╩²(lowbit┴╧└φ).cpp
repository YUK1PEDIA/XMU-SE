int lowbit(int n)
{
    return n & -n;
}
int NumberOf1(int n)
{
    int res = 0;
    for (int i = n; i; i -= lowbit(i))
        res++;
    return res;
}
