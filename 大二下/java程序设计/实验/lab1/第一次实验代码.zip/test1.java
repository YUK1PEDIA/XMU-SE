import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class test1 {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("请输入您的名字：");
            String name = reader.readLine();
            System.out.println("您好，" + name + "!");
        } catch (IOException e) {
            e.printStackTrace();
        }
//        System.out.print("Enter first integer:");
//        int num1 = sc.nextInt();
//        System.out.print("Enter second integer:");
//        int num2 = sc.nextInt();
//        int sum = num1 + num2;
//        System.out.printf("Sum is %d\n", sum);
    }
}
