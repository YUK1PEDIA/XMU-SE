package com.example.exam2;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class EmpController {
    @FXML
    private TextArea employeeListTextArea;
    @FXML
    private TextField ID;
    @FXML
    private TextField Name;
    @FXML
    private TextField Department;
    @FXML
    private TextField Level;

    // 存放员工对象的列表
    private List<Employee> employeeList = new ArrayList<>();
    // 当前选中的员工对象
    private Employee selectedEmployee;

    // 初始化
    @FXML
    public void initialize() {
        updateEmployeeListTextArea();
    }

    // 新增员工
    @FXML
    private void handleAddNew() {
        // 从用户输入框中获取信息
        Employee newEmployee = new Employee(ID.getText(), Name.getText(), Department.getText(), Level.getText());
        employeeList.add(newEmployee); // 在employee列表中增加员工对象
        updateEmployeeListTextArea(); // 更新界面左侧信息栏
    }

    // 保存员工数据
    @FXML
    private void handleSaveEmployee() {
        if (selectedEmployee != null) {
            // 当前选中员工不为空对象，就直接保存相关数据即可
            selectedEmployee.setId(ID.getText());
            selectedEmployee.setName(Name.getText());
            selectedEmployee.setDepartment(Department.getText());
            selectedEmployee.setLevel(Level.getText());
            updateEmployeeListTextArea();
        }
    }

    // 删除员工数据
    @FXML
    private void handleDeleteEmployee() {
        if (selectedEmployee != null) {
            // 在列表中移去当前员工对象
            employeeList.remove(selectedEmployee);
            selectedEmployee = null;
            ID.clear();
            Name.clear();
            Department.clear();
            Level.clear();
            updateEmployeeListTextArea();
        }
    }

    // 保存至文件
    @FXML
    private void handleSaveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\Code\\java\\exam2\\src\\main\\resources\\com\\example\\exam2\\employeesData.txt"))) {
            for (Employee employee : employeeList) {
                String line = "ID：" + employee.getId() + "\n" + "姓名：" + employee.getName() + "\n" + "部门："
                        + employee.getDepartment() + "\n" + "岗位级别" + employee.getLevel() + "\n";
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 选中左侧信息框中的对象
    @FXML
    private void handleEmployeeSelection() {
        // 根据选中的文本，在已有的列表中匹配当前对象
        String selectedEmployeeId = employeeListTextArea.getSelectedText();
        for (Employee employee : employeeList) {
            // 匹配的id相同，则代表找到了该对象
            if (employee.getId().equals(selectedEmployeeId)) {
                selectedEmployee = employee;
                ID.setText(employee.getId());
                Name.setText(employee.getName());
                Department.setText(employee.getDepartment());
                Level.setText(employee.getLevel());
                break;
            }
        }
    }

    // 每次操作完成后更新左侧信息栏
    private void updateEmployeeListTextArea() {
        employeeListTextArea.clear();
        for (Employee employee : employeeList) {
            employeeListTextArea.appendText(employee.getId() + "\n");
        }
    }
}
