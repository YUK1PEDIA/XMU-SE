// 慢速充电桩
public class Slow_Charger extends Charger{
    public Slow_Charger(String type, int num, String location, String max_I, String kV) throws IllegalArgumentException{
        super(type, num, location, max_I, kV);
    }

    private double danjia = 1.1; // 充电单价

    public double getDanjia() {
        return danjia;
    }

    public void setDanjia(double danjia) {
        this.danjia = danjia;
    }
}
