// 充电桩父类
public class Charger {
    private String type; // 充电桩种类
    private int num; // 充电桩编号
    private String location; // 充电桩位置
    private String max_I; // 最大电流
    private String kV; // 电压
    private int dushu; // 充电度数
    private int time; // 充电时间
    private double cost; // 已充电费用

    public Charger(String type, int num, String location, String max_I, String kV)throws IllegalArgumentException {
        if (!(num >= 1 && num <= 9999)) {
            throw new IllegalArgumentException("编号不满足要求");
        }
        this.type = type;
        this.num = num;
        this.location = location;
        this.max_I = max_I;
        this.kV = kV;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getDushu() {
        return dushu;
    }

    public void setDushu(int dushu) {
        this.dushu = dushu;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Charger{" +
                "num=" + num +
                ", location='" + location + '\'' +
                ", max_I='" + max_I + '\'' +
                ", kV='" + kV + '\'' +
                '}';
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getMax_I() {
        return max_I;
    }

    public void setMax_I(String max_I) {
        this.max_I = max_I;
    }

    public String getkV() {
        return kV;
    }

    public void setkV(String kV) {
        this.kV = kV;
    }
}
