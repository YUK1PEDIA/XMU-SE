// 快充（汽车充电桩）
public class Fast_Charger extends Charger {
    public Fast_Charger(String type, int num, String location, String max_I, String kV) throws IllegalArgumentException{
        super(type, num, location, max_I, kV);
    }


    private double danjia = 1.2; // 充电单价
    private int time_cost = 1; // 时间成本



    public double getDanjia() {
        return danjia;
    }

    public void setDanjia(double danjia) {
        this.danjia = danjia;
    }

    public int getTime_cost() {
        return time_cost;
    }

    public void setTime_cost(int time_cost) {
        this.time_cost = time_cost;
    }

}
