import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        menu(); // 显示主菜单
        int choice = 0; // 记录用户选择

        // 创建两个ArrayList记录快充与慢充充电桩的信息
        ArrayList<Fast_Charger> fastChargers = new ArrayList<>();
        ArrayList<Slow_Charger> slowChargers = new ArrayList<>();
        ArrayList<Charger> chargers = new ArrayList<>();

        while (true) {
            // 先检查是否为整数，若不为整数则捕获异常进行处理
            try {
                choice = in.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("输入错误，请重新输入！");
                in.nextLine(); // 消除回车
                menu();
                continue;
            }

            in.nextLine(); // 消除前导回车
            if (choice == 6) break; // 用户输入退出

            if (!(choice >= 1 && choice < 6)) {
                System.out.println("输入整数范围是1-6，请重新输入！");
                in.nextLine(); // 消除回车
                menu();
                continue;
            }

            switch (choice) {
                case 1: {
                    show1(); // 显示主菜单
                    String info = null; // 记录输入的信息
                    while (true) {
                        String flag = null; // 判断是否继续输入

                        info = in.nextLine(); // 读入信息
                        String[] StrArr = info.split("[ ]+"); // 按空格分隔字符串
                        // 判断输入参数个数是否正确
                        if (StrArr.length != 5) {
                            System.out.println("输入参数个数错误！请重新输入");
                            continue;
                        }
                        if (StrArr[0].equals("快充")) { // 若当前读入的是快充
                            try {
                                fastChargers.add(Add_Fast(StrArr)); // 添加相应对象
                                chargers.add(Add_Fast(StrArr)); // 在总充电桩中添加相应对象
                            } catch (IllegalArgumentException e) {
                                System.out.println("编号不满足要求");
                            }
                        } else if (StrArr[0].equals("慢充")) {
                            try {
                                slowChargers.add(Add_Slow(StrArr));
                                chargers.add(Add_Slow(StrArr)); // 在总充电桩中添加相应对象
                            } catch (IllegalArgumentException e) {
                                System.out.println("编号不满足要求");
                            }
                        }
                        System.out.println("是否结束新增？是就输入Y，输入其他内容就继续新增");
                        flag = in.nextLine();
                        if (flag.equals("Y")) break;
                        show1(); // 再次显示输入菜单
                    }
                    menu(); // 显示主菜单
                    break;
                }

                case 2: {
                    // 存放随机获取的设备
                    ArrayList<Charger> random1 = new ArrayList<>();
                    random1 = Get_Half(chargers);
                    // 进行充电
                    for (int i = 0; i < random1.size(); i++) {
                        System.out.println("当前选择的充电桩是：");
                        System.out.println(random1.get(i).getType() + " " + random1.get(i).getNum() + " " + random1.get(i).getLocation() + " "
                                + random1.get(i).getMax_I() + " " + random1.get(i).getkV());

                        if (random1.get(i).getType().equals("快充")) { // 若是快充
                            System.out.println("请输入充电时间：(单位:分钟)");
                            random1.get(i).setTime(in.nextInt()); // 读入充电时间
                            in.nextLine(); // 消除回车

                            System.out.println("请输入充电度数：(单价：1.2元/度)");
                            random1.get(i).setDushu(in.nextInt()); // 读入充电度数
                            in.nextLine(); // 消除回车

                            // 计算费用
                            random1.get(i).setCost(1.2 * random1.get(i).getDushu() + random1.get(i).getTime() / 20.0);
                        } else {
                            System.out.println("请输入充电度数：(单价：1.1元/度)");
                            random1.get(i).setDushu(in.nextInt()); // 读入充电度数
                            in.nextLine(); // 消除回车

                            // 计算费用
                            random1.get(i).setCost(1.1 * random1.get(i).getDushu());
                        }
                    }
//                    for (Charger i : random1) {
//                        System.out.println(i.getType() + " " + i.getNum() + " " + i.getLocation() + " "
//                         + i.getMax_I() + " " + i.getkV());
//                    }
                    System.out.println("计费完成！");
                    menu();
                    break;
                }

                case 3: {
                    show_All(chargers); // 打印出所有充电桩的信息
                    System.out.print("\n");
                    menu();
                    break;
                }

                case 4: {
                    show_Cost(chargers); // 展示所有充电桩已充电费用
                    System.out.println("\n");
                    menu();
                    break;
                }

                case 5: { // 将慢速充电桩收费标准上涨5%
                    for (int i = 0; i < slowChargers.size(); i++) {
                        slowChargers.get(i).setDanjia(1.05 * slowChargers.get(i).getDanjia());
                    }
                    System.out.println("上涨成功！");
                    menu();
                    break;
                }
            }
        }
    }

    // 显示主菜单
    public static void menu() {
        System.out.println("请输入命令编号：");
        System.out.println("1.新增充电桩");
        System.out.println("2.充电桩充电");
        System.out.println("3.列出所有充电桩信息");
        System.out.println("4.列出每台充电桩已充电费用");
        System.out.println("5.将快速充电桩收费标准上涨5%");
        System.out.println("6.退出");
    }

    // 显示输入菜单
    public static void show1() {
        System.out.println("请按照以下格式输入：");
        System.out.println("编号、位置、最大电流、电压");
        System.out.println("如：");
        System.out.println("快充 111 西部片区 400A 250KW");
        System.out.println("慢充 222 主校区 100A 6KW");
        System.out.println("其中“编号”为1-9999的整数。");
    }

    // 添加快速充电桩
    public static Fast_Charger Add_Fast(String[] StrArr) {
        String type;
        int num; // 编号
        String location; // 位置
        String max_I; // 最大电流
        String kV; // 电压
        // 处理字符串
        type = StrArr[0];
        num = Integer.parseInt(StrArr[1]);
        location = StrArr[2];
        max_I = StrArr[3];
        kV = StrArr[4];

        System.out.println("输入成功");
        return new Fast_Charger(type, num, location, max_I, kV);
    }

    // 添加慢速充电桩
    public static Slow_Charger Add_Slow(String[] StrArr) {
        String type;
        int num; // 编号
        String location; // 位置
        String max_I; // 最大电流
        String kV; // 电压
        // 处理字符串
        type = StrArr[0];
        num = Integer.parseInt(StrArr[1]);
        location = StrArr[2];
        max_I = StrArr[3];
        kV = StrArr[4];

        System.out.println("输入成功");
        return new Slow_Charger(type, num, location, max_I, kV);
    }

    // 随机获取一半对象
    public static ArrayList<Charger> Get_Half(ArrayList<Charger> chargers) {
        // 创建 Random 对象
        Random random = new Random();

        // 创建一个包含随机索引的列表
        List<Integer> randomIndexes = new ArrayList<>();
        int halfSize = chargers.size() / 2;
        for (int i = 0; i < halfSize; i++) {
            int index = random.nextInt(chargers.size());
            randomIndexes.add(index);
        }

        // 构建一个新的 ArrayList，其中包含原始 ArrayList 中随机选择的元素
        ArrayList<Charger> resultList = new ArrayList<>();
        for (int index : randomIndexes) {
            resultList.add(chargers.get(index));
        }

        return resultList;
    }

    // 打印出所有充电桩的信息
    public static void show_All(ArrayList<Charger> chargers) {
        System.out.println("全部充电桩的信息如下：");
        for (Charger i : chargers) {
            System.out.println(i.getType() + " " + i.getNum() + " " + i.getLocation() + " "
                         + i.getMax_I() + " " + i.getkV());
        }
    }

    // 打印出每台充电桩已充电的费用
    public static void show_Cost(ArrayList<Charger> chargers) {
        System.out.println("全部充电桩已充电的费用如下：");
        System.out.println("---------------------");
        for (Charger i : chargers) {
            System.out.println("编号：" + i.getNum());
            System.out.println("费用：" + i.getCost());
            System.out.println("---------------------");
        }
    }
}

