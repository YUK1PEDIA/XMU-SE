class BMPConverter:
    def __init__(self, input_file, output_file):
        self.input_file = input_file
        self.output_file = output_file

    def read_bmp(self):
        with open(self.input_file, 'rb') as f:
            # 读取文件头
            header = f.read(54)
            # 获取图像宽度和高度
            width = int.from_bytes(header[18:22], byteorder='little')
            height = int.from_bytes(header[22:26], byteorder='little')
            # 获取每个像素占用的字节数
            bpp = int.from_bytes(header[28:30], byteorder='little')
            # 计算每行像素所占的字节数，每个像素占用3字节（24位真彩色）
            row_size = width * 3
            padding = 4 - (row_size % 4)
            if padding == 4:
                padding = 0
            # 计算像素数据偏移量
            pixel_offset = int.from_bytes(header[10:14], byteorder='little')
            # 读取图像数据
            pixel_data = []
            f.seek(pixel_offset)
            for _ in range(height):
                row_data = f.read(row_size)
                pixel_data.append(row_data)

        return width, height, bpp, pixel_data

    def convert_to_grayscale(self, pixel_data):
        grayscale_data = []
        for row_data in pixel_data:
            grayscale_row = bytearray()
            for i in range(0, len(row_data), 3):
                # 从RGB值计算灰度值
                pixel = row_data[i:i+3]
                grayscale = int(0.2989 * pixel[2] + 0.5870 * pixel[1] + 0.1140 * pixel[0])
                grayscale_row.append(grayscale)
            grayscale_data.append(grayscale_row)
        return grayscale_data

    def save_as_pseudo_color(self, width, height, grayscale_data):
        with open(self.output_file, 'wb') as f:
            # 写入文件头
            f.write(b'BM')  # 位图文件标识
            file_size = 54 + height * width  # 文件大小
            f.write(file_size.to_bytes(4, byteorder='little'))  # 文件大小
            f.write(b'\x00\x00')  # 保留字
            f.write(b'\x00\x00')  # 保留字
            pixel_offset = 54  # 数据偏移量
            f.write(pixel_offset.to_bytes(4, byteorder='little'))  # 数据偏移量
            # 写入位图信息头
            f.write(b'\x28\x00\x00\x00')  # 信息头大小
            f.write(width.to_bytes(4, byteorder='little'))  # 图像宽度
            f.write(height.to_bytes(4, byteorder='little'))  # 图像高度
            f.write(b'\x01\x00')  # 颜色平面数
            f.write(b'\x08\x00')  # 比特数/像素
            f.write(b'\x00\x00\x00\x00')  # 压缩方式
            f.write(b'\x00\x00\x00\x00')  # 图像大小
            f.write(b'\x00\x00\x00\x00')  # 水平分辨率
            f.write(b'\x00\x00\x00\x00')  # 垂直分辨率
            f.write(b'\x00\x00\x00\x00')  # 使用的颜色数
            f.write(b'\x00\x00\x00\x00')  # 重要的颜色数
            # 写入调色板
            for i in range(256):
                f.write(bytes([i, i, i, 0]))
            # 写入图像数据
            for row in grayscale_data:
                for pixel in row:
                    f.write(bytes([pixel]))
                # 添加填充字节
                padding = 4 - (len(row) % 4)
                if padding != 4:
                    f.write(bytes(padding))

    def convert_and_save(self):
        width, height, bpp, pixel_data = self.read_bmp()
        if bpp != 24:
            print("出现错误")
            return
        grayscale_data = self.convert_to_grayscale(pixel_data)
        self.save_as_pseudo_color(width, height, grayscale_data)
        print("转换完成")


converter = BMPConverter(r"D:\Desktop\实验三素材\实验三素材\24位真彩色BMP\trump.bmp", r"D:\Desktop\实验三素材\实验三素材\8位伪彩色BMP文件结果\result3.bmp")
converter.convert_and_save()
