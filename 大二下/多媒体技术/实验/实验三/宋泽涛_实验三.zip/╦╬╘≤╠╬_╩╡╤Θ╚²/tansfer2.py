class BMPConverter:
    def __init__(self, input_file, output_file):
        self.input_file = input_file
        self.output_file = output_file
        self.header_size = 54

    def convert(self):
        with open(self.input_file, 'rb') as f_in:
            with open(self.output_file, 'wb') as f_out:
                # Copy header
                header_data = f_in.read(self.header_size)
                f_out.write(header_data)

                # Read image dimensions
                f_in.seek(18)  # Offset for width and height data
                width_bytes = f_in.read(4)
                height_bytes = f_in.read(4)
                width = int.from_bytes(width_bytes, byteorder='little')
                height = int.from_bytes(height_bytes, byteorder='little')
                
                # Calculate lineBytes
                line_bytes_pixel = width * 3  # For 24-bit BMP, each pixel occupies 3 bytes
                if line_bytes_pixel % 4 == 0:
                    line_bytes = line_bytes_pixel
                else:
                    line_bytes = ((line_bytes_pixel // 4) + 1) * 4

                # Read and convert pixel data
                f_in.seek(self.header_size)  # Move to the beginning of pixel data
                for _ in range(height):
                    row_data = f_in.read(line_bytes)  # Read one row of pixel data
                    f_out.write(row_data)

if __name__ == "__main__":
    input_file = r"D:\Desktop\实验三素材\实验三素材\8位伪彩色BMP\trump.bmp"
    output_file = r"D:\Desktop\实验三素材\实验三素材\24位真彩色BMP文件结果\result3.bmp"
    converter = BMPConverter(input_file, output_file)
    converter.convert()
    print("Conversion completed successfully!")
