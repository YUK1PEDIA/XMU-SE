# 定义函数计算列表元素的平均值并输出
def calculate_average(data):
    total = sum(data)
    average = total / len(data)
    print("平均值为:", average)

# 定义函数找到列表中的最大值并输出
def find_max(data):
    max_value = max(data)
    print("最大值为:", max_value)

# 定义函数实现冒泡排序并输出排序好的列表
def bubble_sort(data):
    n = len(data)
    for i in range(n-1):
        for j in range(0, n-i-1):
            if data[j] > data[j+1]:
                data[j], data[j+1] = data[j+1], data[j]
    print("排序后的列表为:", data)

# 主函数
if __name__ == "__main__":
    data = [1, 2, 3, 12, 20, 100, 6, 9, 12, 8, 8, 3]
    calculate_average(data)
    find_max(data)
    bubble_sort(data.copy())  # 使用拷贝的副本以保留原始数据
