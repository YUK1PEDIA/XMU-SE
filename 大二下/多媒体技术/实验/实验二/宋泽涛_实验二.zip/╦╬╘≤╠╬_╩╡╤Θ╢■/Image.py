import cv2
import numpy as np
import requests
from io import BytesIO

# 从网上获取四张猫的图像
cat_urls = [
    "https://s2.loli.net/2024/03/27/VXMyiNZ4EBFsOSr.jpg",
    "https://s2.loli.net/2024/03/27/TnZImjAecB6h52x.jpg",
    "https://s2.loli.net/2024/03/27/9ot3sqxhKnzBOwU.jpg",
    "https://s2.loli.net/2024/03/27/Boqhp6ijfXzeU1Y.jpg"
]

# 下载图像并转换为OpenCV可处理的格式
cat_images = []
for url in cat_urls:
    response = requests.get(url)
    img_array = np.array(bytearray(response.content), dtype=np.uint8)
    img = cv2.imdecode(img_array, -1)
    if img is not None:
        cat_images.append(img)
    else:
        print(f"Failed to load image from URL: {url}")

# 检查是否成功加载了至少一张图像
if not cat_images:
    print("No images were successfully loaded. Exiting.")
    exit()

# 调整图像大小为更小的尺寸
target_height = 300
target_width = 300
resized_images = [cv2.resize(img, (target_width, target_height)) for img in cat_images]

# 创建一个画布，用于绘制拼贴画
collage = np.zeros((target_height, target_width * len(resized_images), 3), dtype=np.uint8)

# 在画布上绘制每张猫的图像
x_offset = 0
for img in resized_images:
    h, w = img.shape[:2]
    collage[:, x_offset:x_offset+w] = img
    x_offset += w

# 保存拼贴画
cv2.imwrite("collage.jpg", collage)

# 显示拼贴画（可选）
cv2.imshow("Collage", collage)
cv2.waitKey(0)
cv2.destroyAllWindows()
