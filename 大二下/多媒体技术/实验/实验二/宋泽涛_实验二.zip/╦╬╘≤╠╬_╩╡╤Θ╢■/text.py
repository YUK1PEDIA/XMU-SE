import matplotlib.pyplot as plt
from collections import Counter

# 读取文本文件
with open(r"D:\Desktop\实验二素材\实验二素材\alphatwice.txt", "r") as file:
    text = file.read()

# 统计英文字母出现次数
letter_counts = Counter(char.lower() for char in text if char.isalpha())

# 选择出现次数最高的10个英文字母
top_10_letters = letter_counts.most_common(10)

# 提取字母和对应的出现次数
letters, counts = zip(*top_10_letters)

# 绘制直方图
plt.figure(figsize=(10, 6))
plt.bar(letters, counts, color='skyblue')
plt.xlabel('Letters')
plt.ylabel('Counts')
plt.title('Top 10 Most Common Letters')
plt.savefig('letter_counts_histogram.png')  # 保存为图像文件
plt.show()
