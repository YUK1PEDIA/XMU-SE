import sounddevice as sd
import soundfile as sf
import numpy as np

def remove_even_seconds(input_file, output_file):
    # 读取音频文件
    data, sample_rate = sf.read(input_file)
    
    # 获取音频总时长
    total_seconds = len(data) / sample_rate
    
    # 创建一个空的音频数组
    new_audio = np.array([])
    
    # 去除偶数秒内的音频
    for i in range(int(total_seconds)):
        if (i+1) % 2 != 0:  # 跳过偶数秒
            start_frame = int(i * sample_rate)
            end_frame = int((i+1) * sample_rate)
            new_audio = np.append(new_audio, data[start_frame:end_frame])
    
    # 播放新音频
    sd.play(new_audio, samplerate=sample_rate, blocking=True)
    
    # 保存新音频文件
    sf.write(output_file, new_audio, sample_rate)

if __name__ == "__main__":
    input_file = "D:/Desktop/实验二素材/实验二素材/music.wav"
    output_file = "music_without_even_seconds.wav"
    remove_even_seconds(input_file, output_file)
