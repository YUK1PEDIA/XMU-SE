import struct

class ArithmeticEncoder:
    def __init__(self, text):
        self.text = text  # 初始化文本
        self.frequencies = self.calculate_frequencies()  # 计算字符频率
        self.cumulative_frequencies = self.calculate_cumulative_frequencies()  # 计算累积频率

    # 计算每个字符在文本中出现的频率
    def calculate_frequencies(self):
        frequencies = {}  # 创建一个空字典存放频率
        for char in self.text:
            if char in frequencies:
                frequencies[char] += 1  # 如果字符已存在，频率加1
            else:
                frequencies[char] = 1  # 如果字符不存在，初始化频率为1
        total = len(self.text)  # 计算文本长度
        for char in frequencies:
            frequencies[char] /= total  # 将每个字符的频率转换为概率
        return frequencies

    # 计算每个字符的累积频率
    def calculate_cumulative_frequencies(self):
        cumulative_frequencies = {}  # 创建一个空字典存放累积频率
        cumulative = 0.0  # 初始化累积频率
        for char in sorted(self.frequencies):
            cumulative_frequencies[char] = cumulative  # 存储当前字符的累积频率
            cumulative += self.frequencies[char]  # 累加当前字符的频率
        return cumulative_frequencies

    # 编码函数，返回编码后的值
    def encode(self):
        low, high = 0.0, 1.0  # 初始化区间为[0, 1)
        for char in self.text:
            range_width = high - low  # 计算当前区间宽度
            high = low + range_width * (self.cumulative_frequencies[char] + self.frequencies[char])  # 更新high值
            low = low + range_width * self.cumulative_frequencies[char]  # 更新low值
        return (low + high) / 2  # 返回最终区间的中点

    # 解码函数，通过编码后的值和文本长度返回解码后的文本
    def decode(self, encoded_value, text_length):
        low, high = 0.0, 1.0  # 初始化区间为[0, 1)
        decoded_text = ""  # 初始化解码后的文本
        for _ in range(text_length):
            range_width = high - low  # 计算当前区间宽度
            value = (encoded_value - low) / range_width  # 计算编码值在当前区间的位置
            for char in sorted(self.cumulative_frequencies):
                if self.cumulative_frequencies[char] <= value < self.cumulative_frequencies[char] + self.frequencies[char]:
                    decoded_text += char  # 将字符添加到解码文本中
                    high = low + range_width * (self.cumulative_frequencies[char] + self.frequencies[char])  # 更新high值
                    low = low + range_width * self.cumulative_frequencies[char]  # 更新low值
                    break
        return decoded_text  # 返回解码后的文本

    # 将浮点数转换为二进制字符串
    def float_to_binary(self, value):
        [d] = struct.unpack(">Q", struct.pack(">d", value))
        return f"{d:064b}"  # 返回64位二进制字符串

    # 将二进制字符串转换回浮点数
    def binary_to_float(self, binary):
        h = int(binary, 2)  # 将二进制字符串转换为整数
        return struct.unpack(">d", struct.pack(">Q", h))[0]  # 将整数转换回浮点数

if __name__ == "__main__":
    # 硬编码的文件路径
    input_file_path = r"D:\Desktop\实验五\实验四素材\实验四素材\text file\as.txt"  # 输入文件路径
    encoded_output_path = r"D:\Desktop\实验五\实验四素材\实验四素材\result\as.txt"  # 编码值输出文件路径

    # 读取输入文件
    with open(input_file_path, "r", encoding="utf-8") as file:
        input_text = file.read().strip()  # 读取文件内容并去除首尾空格

    # 对输入文本进行编码和解码
    encoder = ArithmeticEncoder(input_text)
    encoded_value = encoder.encode()  # 编码
    encoded_binary = encoder.float_to_binary(encoded_value)  # 将编码值转换为二进制字符串
    decoded_value = encoder.binary_to_float(encoded_binary)  # 将二进制字符串转换回浮点数
    decoded_text = encoder.decode(decoded_value, len(input_text))  # 解码

    # 打印结果
    print(f"原始文本: {input_text}")
    print(f"编码值: {encoded_value}")
    print(f"编码二进制: {encoded_binary}")
    print(f"解码文本: {decoded_text}")

    # 将编码值保存到文件
    with open(encoded_output_path, "w", encoding="utf-8") as file:
        file.write(encoded_binary)
