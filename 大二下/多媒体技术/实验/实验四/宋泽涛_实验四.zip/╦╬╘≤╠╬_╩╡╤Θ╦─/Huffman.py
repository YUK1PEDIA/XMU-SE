import heapq
import os

# 定义哈夫曼树的节点类
class HuffmanNode:
    def __init__(self, char, freq):
        self.char = char  # 节点存储的字符
        self.freq = freq  # 字符出现的频率
        self.left = None  # 左子节点
        self.right = None  # 右子节点

    # 定义节点的比较方法（通过字符出现的频率来比较）
    def __lt__(self, other):
        return self.freq < other.freq

# 构建哈夫曼树
def build_huffman_tree(freq_dict):
    # 创建一个优先队列，先存储所有的节点
    priority_queue = [HuffmanNode(char, freq) for char, freq in freq_dict.items()]
    heapq.heapify(priority_queue) # 将列表转化为最小堆
    
    # 对优先队列中队首的两个元素进行合并操作
    while len(priority_queue) > 1:
        left = heapq.heappop(priority_queue) # 队首元素，最小元素
        right = heapq.heappop(priority_queue) # 第二个元素，次小元素
        
        # 创建新节点，节点值为优先队列队首两元素之和
        merged = HuffmanNode(None, left.freq + right.freq)
        
        # 确保EOF在队尾，保证哈夫曼编码的正确性
        if left.char == "EOF":
            merged.left = right
            merged.right = left
        else:
            merged.left = left
            merged.right = right
        
        heapq.heappush(priority_queue, merged) # 向原队列插入新节点
    
    # 打印出完成合并的优先队列，即哈夫曼树
    print_huffman_tree(priority_queue[0])
    return priority_queue[0] # 返回哈夫曼树的根节点

# 打印哈夫曼树
def print_huffman_tree(node, level=0):
    if node is not None:
        print("    " * level + f"Character: {node.char}, Frequency: {node.freq}")
        print_huffman_tree(node.left, level + 1)
        print_huffman_tree(node.right, level + 1)

# 构建哈夫曼编码表
def build_huffman_table(root):
    # 先创建空表
    huffman_table = {}
    
    # 从根节点开始遍历，计算每个节点的哈夫曼编码
    def traverse(node, code):
        if node.char is not None:
            huffman_table[node.char] = code
            return
        traverse(node.left, code + '0')
        traverse(node.right, code + '1')
    
    traverse(root, '')
    return huffman_table

# 特殊获取EOF的哈夫曼编码
def get_EOF_huffman_code(node, target_char, current_code=""):
    # 如果当前节点为空，则返回空字符串
    if node is None:
        return ""
    
    # 如果当前节点是叶子节点，并且包含目标字符
    if node.char == target_char and node.char is not None:
        return current_code
    
    # 递归搜索左子树，并在当前编码基础上添加0
    left_code = get_EOF_huffman_code(node.left, target_char, current_code + "0")
    if left_code:  # 如果左子树中找到了目标字符，则直接返回其编码
        return left_code
    
    # 递归搜索右子树，并在当前编码基础上添加1
    right_code = get_EOF_huffman_code(node.right, target_char, current_code + "1")
    if right_code:  # 如果右子树中找到了目标字符，则直接返回其编码
        return right_code
    
    # 如果左右子树都没有找到目标字符，则返回空字符串
    return ""

# 对文本用哈夫曼编码表进行编码压缩
def encode_text(text, huffman_table):
    encoded_text = ''
    for char in text:
        encoded_text += huffman_table[char]
    return encoded_text

# 压缩文件
def compress_file(input_file, output_file):
    # 首先统计文件中各个字符的频率
    freq_dict = {}
    with open(input_file, 'r', encoding='utf-8') as file:
        for line in file:
            for char in line:
                if char in freq_dict:
                    freq_dict[char] += 1
                else:
                    freq_dict[char] = 1
    
    # 确保包含EOF，并将其频率设置为 1
    freq_dict["EOF"] = 1
    
    # 构建哈夫曼树和编码表
    root = build_huffman_tree(freq_dict)
    huffman_table = build_huffman_table(root)
    
    # 使用哈夫曼编码表对文本进行编码
    encoded_text = ''
    with open(input_file, 'r', encoding='utf-8') as file:
        for line in file:
            encoded_text += encode_text(line, huffman_table)
        
    
    # 将编码后的文本写入输出文件
    eof_code = get_EOF_huffman_code(root, "EOF") # 获取EOF的哈夫曼编码
    with open(output_file, 'w', encoding='utf-8') as file:
        file.write(encoded_text) # 写入文件经压缩后的哈夫曼编码（不包含EOF的编码）
        file.write(eof_code) # 在文件结尾写上EOF的哈夫曼编码

input_file = r"D:\Desktop\实验四\实验四素材\实验四素材\text file\alphatwice.txt"
output_file = r"D:\Desktop\实验四\实验四素材\实验四素材\result\alphatwice_encode.txt"
compress_file(input_file, output_file) # 压缩文件
