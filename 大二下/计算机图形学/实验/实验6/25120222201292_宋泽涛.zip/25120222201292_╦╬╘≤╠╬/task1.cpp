﻿#define _CRT_SECURE_NO_WARNINGS 1
#include <GL/glut.h>
#include <windows.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>

using namespace std;

double mouseX, mouseY; // 鼠标点击的位置
int point_num = 0; // 当前控制点的数量
bool isAnimating = false; // 动画是否正在进行的标志

// 控制点的数组，最多支持8个点
GLfloat ctrlPoints[8][2] = {};

void init(void) {
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION); 
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW); 
}

// 绘制控制点
void drawControlPoints() {
    glColor3f(1.0, 0.0, 0.0); // 设置颜色为红色
    glPointSize(5.0); // 设置点的大小
    glBegin(GL_POINTS); // 开始绘制点
    for (int i = 0; i < point_num; i++) {
        glVertex2fv(ctrlPoints[i]); // 绘制每个控制点
    }
    glEnd(); // 结束绘制点
}

// de Casteljau算法，用于计算贝塞尔曲线上点的坐标
vector<float> deCasteljau(vector<vector<float>> points, float t) {
    while (points.size() > 1) {
        vector<vector<float>> newPoints;
        for (size_t i = 0; i < points.size() - 1; ++i) {
            vector<float> point = {
                (1 - t) * points[i][0] + t * points[i + 1][0],
                (1 - t) * points[i][1] + t * points[i + 1][1]
            };
            newPoints.push_back(point);
        }
        points = newPoints;
    }
    return points[0];
}

// 生成并动画展示贝塞尔曲线
void animateBezierCurve() {
    isAnimating = true; // 设置动画标志
    GLfloat ps[101][2]; // 存储贝塞尔曲线上的点
    int u = 0;

    // 将控制点转化为vector形式
    vector<vector<float>> points;
    for (int i = 0; i < point_num; i++) {
        points.push_back({ ctrlPoints[i][0], ctrlPoints[i][1] });
    }

    // 计算贝塞尔曲线上的点
    for (float t = 0.0; t <= 1; t += 0.01) {
        vector<float> point = deCasteljau(points, t);
        ps[u][0] = point[0];
        ps[u][1] = point[1];
        u++;
    }

    // 动画展示贝塞尔曲线生成过程
    for (int times = 0; times < 100; ++times) {
        glClear(GL_COLOR_BUFFER_BIT); // 清除屏幕内容
        drawControlPoints(); // 绘制控制点

        glColor3f(0.0, 0.0, 1.0); // 设置颜色为蓝色
        glBegin(GL_LINE_STRIP); // 开始绘制线段
        for (int i = 0; i <= times; ++i) {
            glVertex2fv(ps[i]); 
        }
        glEnd();

        glColor3f(0, 0, 0); 
        glBegin(GL_POINTS); 
        glVertex2fv(ps[times]); // 绘制当前动画点
        glEnd();

        glutSwapBuffers(); // 切换缓冲区，显示绘制内容
        this_thread::sleep_for(chrono::milliseconds(50)); // 延迟以形成动画效果
    }

    isAnimating = false; // 重置动画标志
}

// 显示回调函数
void display(void) {
    glClear(GL_COLOR_BUFFER_BIT); // 清除屏幕内容
    drawControlPoints(); // 绘制控制点

    // 如果控制点数目达到3个且动画未进行，则生成贝塞尔曲线动画
    if (point_num >= 3 && !isAnimating) {
        animateBezierCurve();
    }

    glFlush(); // 强制刷新OpenGL命令
}

// 鼠标点击回调函数
void mouseFunc(int button, int state, int x, int y) {
    // 如果左键按下且未超过最大控制点数量
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && point_num < 8) {
        // 转换屏幕坐标为OpenGL坐标
        float mx = (float)x / (500 / 2) - 1;
        float my = 1 - (float)y / (500 / 2);
        ctrlPoints[point_num][0] = mx;
        ctrlPoints[point_num][1] = my;
        point_num++;
        glutPostRedisplay(); // 重新绘制窗口内容
    }
}

// 键盘回调函数
void keyboard(unsigned char key, int x, int y) {
    if (key == 27) {
        exit(0);
    }
}

// 窗口大小改变回调函数
void reshape(int w, int h) {
    glViewport(0, 0, (GLsizei)w, (GLsizei)h); // 设置视口大小
    glMatrixMode(GL_PROJECTION); // 设置投影矩阵
    glLoadIdentity(); // 重置投影矩阵
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0); // 设置正交投影范围
    glMatrixMode(GL_MODELVIEW); // 设置模型视图矩阵
    glLoadIdentity(); // 重置模型视图矩阵
}

// 空闲回调函数
void myidle() {
    Sleep(15); 
    glutPostRedisplay(); // 重新绘制窗口内容
}

// 主函数
int main(int argc, char* argv[]) {
    glutInit(&argc, argv); 
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE); 
    glutInitWindowPosition(100, 100); 
    glutInitWindowSize(500, 500); 
    glutCreateWindow(argv[0]); 
    init(); 
    glutDisplayFunc(display);
    glutReshapeFunc(reshape); 
    glutIdleFunc(myidle); 
    glutKeyboardFunc(keyboard); 
    glutMouseFunc(mouseFunc); 
    glutMainLoop();
    return 0;
}
