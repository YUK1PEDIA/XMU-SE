#include <GL/glut.h>
#include <cmath>
#include <iostream>
#include <cstring>

using namespace std;

// ���峣��
constexpr int MAX_CONTROL_POINTS = 6;
constexpr int ANIMATION_DELAY = 10;
constexpr int CONTROL_POINT_SIZE = 10;
constexpr int CURVE_LINE_WIDTH = 5;

// ȫ�ֱ���
static bool isMousePressed = false;
static GLdouble animationTime = 0;
static GLint selectedRow = -1, selectedCol = -1;

// ��ṹ��
struct Point {
    GLdouble x, y, z;
    Point() : x(0), y(0), z(0) {}
    Point(GLdouble xx, GLdouble yy) : x(xx), y(yy), z(0) {}
    Point(GLdouble xx, GLdouble yy, GLdouble zz) : x(xx), y(yy), z(zz) {}
};

// ���Ƶ�
void drawPoint(Point p) {
    glBegin(GL_POINTS);
    glVertex3f(p.x, p.y, p.z);
    glEnd();
}

// ������
void drawLine(Point p1, Point p2) {
    glBegin(GL_LINES);
    glVertex3f(p1.x, p1.y, p1.z);
    glVertex3f(p2.x, p2.y, p2.z);
    glEnd();
}

// Bezier��
class BezierSurface {
public:
    BezierSurface();
    void drawSurface(GLdouble time);
    void setControlPoint(GLint x, GLint y);
    bool isControlPointSelected(GLfloat x, GLfloat y);
    void addControlPoint();
    Point calculateBezierPoint(GLdouble t, GLint row);
    Point calculateBezierPoint(GLdouble t, Point* points);

private:
    GLint controlPointCount;
    Point controlPoints[MAX_CONTROL_POINTS][MAX_CONTROL_POINTS];
    GLdouble bezierCoefficients[MAX_CONTROL_POINTS];
    GLint binomialCoefficient(int k, int n);
};

static BezierSurface bezierSurface;

// ��ʼ��OpenGL
void initializeOpenGL() {
    glClearColor(1.0, 1.0, 1.0, 0);
    glPointSize(CONTROL_POINT_SIZE);
    glLineWidth(CURVE_LINE_WIDTH);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, glutGet(GLUT_WINDOW_WIDTH), 0.0, glutGet(GLUT_WINDOW_HEIGHT));
    glClear(GL_COLOR_BUFFER_BIT);
}

// ��ʾ�ص�����
void displayCallback() {
    glClear(GL_COLOR_BUFFER_BIT);
    bezierSurface.drawSurface(animationTime);
    Sleep(ANIMATION_DELAY);
    glutSwapBuffers();
}

// ������ص�����
void mouseCallback(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            isMousePressed = true;
            if (bezierSurface.isControlPointSelected(x, glutGet(GLUT_WINDOW_HEIGHT) - y))
                return;
            selectedRow = -1;
            selectedCol = -1;
        }
        else if (state == GLUT_UP) {
            isMousePressed = false;
        }
    }
}

// ����ƶ��ص�����
void mouseMotionCallback(int x, int y) {
    if (isMousePressed && selectedRow != -1 && selectedCol != -1) {
        bezierSurface.setControlPoint(x, glutGet(GLUT_WINDOW_HEIGHT) - y);
        animationTime = 0;
        glutPostRedisplay();
    }
}

// ���̻ص�����
void keyboardCallback(unsigned char key, int x, int y) {
    if (key == 'a') {
        bezierSurface.addControlPoint();
    }
    glutPostRedisplay();
}

// ���лص�����
void idleCallback() {
    animationTime += 0.005;
    if (animationTime >= 1.0) animationTime = 0.0;
    glutPostRedisplay();
}

// �������ʽϵ��
GLint BezierSurface::binomialCoefficient(int k, int n) {
    GLint result = 1;
    for (int i = 1; i <= k; ++i) {
        result = result * (n + 1 - i) / i;
    }
    return result;
}

// Bezier�๹�캯��
BezierSurface::BezierSurface() {
    memset(bezierCoefficients, 0, sizeof bezierCoefficients);
    controlPointCount = 3;
    for (int i = 0; i < controlPointCount; ++i) {
        for (int j = 0; j < controlPointCount; ++j) {
            controlPoints[i][j] = Point((i + 1) * 680 / (controlPointCount + 1), (j + 1) * 480 / (controlPointCount + 1));
        }
    }
}

// ����Bezier�����ϵ�ĺ���
Point BezierSurface::calculateBezierPoint(GLdouble t, GLint row) {
    Point p(0, 0);
    for (int i = 0; i < controlPointCount; ++i) {
        bezierCoefficients[i] = pow((1 - t), controlPointCount - i - 1) * pow(t, i) * binomialCoefficient(i, controlPointCount - 1);
    }
    for (int i = 0; i < controlPointCount; ++i) {
        p.x += bezierCoefficients[i] * controlPoints[row][i].x;
        p.y += bezierCoefficients[i] * controlPoints[row][i].y;
    }
    return p;
}

// ����Bezier�����ϵ�ĺ�����ʹ�ø�����
Point BezierSurface::calculateBezierPoint(GLdouble t, Point* points) {
    Point p(0, 0);
    for (int i = 0; i < controlPointCount; ++i) {
        bezierCoefficients[i] = pow((1 - t), controlPointCount - i - 1) * pow(t, i) * binomialCoefficient(i, controlPointCount - 1);
    }
    for (int i = 0; i < controlPointCount; ++i) {
        p.x += bezierCoefficients[i] * points[i].x;
        p.y += bezierCoefficients[i] * points[i].y;
    }
    return p;
}

// ���������Ƿ�ѡ�п��Ƶ�
bool BezierSurface::isControlPointSelected(GLfloat x, GLfloat y) {
    for (int i = 0; i < controlPointCount; ++i) {
        for (int j = 0; j < controlPointCount; ++j) {
            if (abs(x - controlPoints[i][j].x) <= CONTROL_POINT_SIZE / 2 + 3 && abs(y - controlPoints[i][j].y) <= CONTROL_POINT_SIZE / 2 + 3) {
                selectedRow = i;
                selectedCol = j;
                return true;
            }
        }
    }
    return false;
}

// ����ѡ�п��Ƶ��λ��
void BezierSurface::setControlPoint(GLint x, GLint y) {
    controlPoints[selectedRow][selectedCol].x = x;
    controlPoints[selectedRow][selectedCol].y = y;
}

// ����Bezier����
void BezierSurface::drawSurface(GLdouble temp) {
    // ���ƿ��Ƶ���߶�
    for (int i = 0; i < controlPointCount; ++i) {
        for (int j = 0; j < controlPointCount - 1; ++j) {
            glColor3ub(149, 219, 125); // �߶���ɫ
            drawLine(controlPoints[i][j], controlPoints[i][j + 1]);
            glColor3f(1.0f, 0.0f, 0.0f); // ���Ƶ���ɫ
            drawPoint(controlPoints[i][j]);
            drawPoint(controlPoints[i][j + 1]);
        }
    }

    // ����Bezier����
    for (int i = 0; i < controlPointCount; ++i) {
        Point previousPoint = controlPoints[i][0];
        for (GLdouble t = 0.0; t <= 1.05; t += 0.05) {
            Point currentPoint = calculateBezierPoint(t, i);
            glColor3ub(133, 192, 206); // Bezier������ɫ
            drawLine(previousPoint, currentPoint);
            previousPoint = currentPoint;
        }
    }

    // ����Bezier����
    for (GLdouble f = 0.0; f <= temp; f += 0.003) {
        Point tempPoints[MAX_CONTROL_POINTS];
        for (int i = 0; i < controlPointCount; ++i) {
            tempPoints[i] = calculateBezierPoint(f, i);
        }
        Point previousPoint = tempPoints[0];
        for (GLdouble t = 0.0; t <= 1.05; t += 0.05) {
            glLineWidth(3);
            Point currentPoint = calculateBezierPoint(t, tempPoints);
            glColor4ub(255, 0, 0, 128); // Bezier������ɫ
            drawLine(previousPoint, currentPoint);
            previousPoint = currentPoint;
        }
    }
    glFlush();
}

// ����һ����Ƶ�
void BezierSurface::addControlPoint() {
    if (controlPointCount < MAX_CONTROL_POINTS)
        ++controlPointCount;
}

// ������
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowSize(600, 480);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Bezier Surface");
    initializeOpenGL();
    glutMouseFunc(&mouseCallback);
    glutMotionFunc(&mouseMotionCallback);
    glutKeyboardFunc(&keyboardCallback);
    glutDisplayFunc(&displayCallback);
    glutIdleFunc(&idleCallback);
    glutMainLoop();
    return 0;
}
