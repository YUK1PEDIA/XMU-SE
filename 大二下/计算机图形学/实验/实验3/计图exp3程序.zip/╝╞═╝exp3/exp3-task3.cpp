#include <GL/glut.h>
#include <math.h>

#define DEG_TO_RAD 0.017453
const GLfloat RR = 2.0; //camera rad
GLfloat beta = 0;

// Material properties
GLfloat brassAmbient[] = { 0.33f, 0.22f, 0.03f, 1.0f };
GLfloat brassDiffuse[] = { 0.78f, 0.57f, 0.11f, 1.0f };
GLfloat brassSpecular[] = { 0.99f, 0.91f, 0.81f, 1.0f };
GLfloat brassShininess = 27.8f;

GLfloat redPlasticAmbient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat redPlasticDiffuse[] = { 0.5f, 0.0f, 0.0f, 1.0f };
GLfloat redPlasticSpecular[] = { 0.7f, 0.6f, 0.6f, 1.0f };
GLfloat redPlasticShininess = 32.0f;

GLfloat whiteShinyAmbient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat whiteShinyDiffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f };
GLfloat whiteShinySpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat whiteShinyShininess = 100.0f;

// Light properties
GLfloat light0Position[] = { 0.0f, 0.0f, 2.0f, 1.0f };
GLfloat light0Ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat light0Diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat light0Specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };

GLfloat light1Position[] = { 0.0f, 0.0f, 2.0f, 1.0f };
GLfloat light1Ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat light1Diffuse[] = { 1.0f, 0.0f, 0.0f, 1.0f }; // Red light
GLfloat light1Specular[] = { 1.0f, 0.0f, 0.0f, 1.0f };

void init(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);

    // Enable depth testing
    glEnable(GL_DEPTH_TEST);

    // Enable lighting
    glEnable(GL_LIGHTING);

    // Enable light0
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, light0Position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light0Ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light0Diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light0Specular);

    // Enable light1
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT1, GL_POSITION, light1Position);
    glLightfv(GL_LIGHT1, GL_AMBIENT, light1Ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light1Diffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light1Specular);

    // Set default material
    glMaterialfv(GL_FRONT, GL_AMBIENT, brassAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, brassDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, brassSpecular);
    glMaterialf(GL_FRONT, GL_SHININESS, brassShininess);
}

void display(void)
{
    // Clear the color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Reset transformations
    glLoadIdentity();

    // Set camera position
    gluLookAt(RR * sin(beta * DEG_TO_RAD), RR * cos(beta * DEG_TO_RAD) * cos(45.0), RR * cos(beta * DEG_TO_RAD) * sin(45),
        0.0, 0.0, 0.0,
        0.0, 1.0, 0.0);

    // Draw the cube
    glBegin(GL_TRIANGLES);
    // face A, part 1
    glVertex3f(-1, 1, -1);
    glVertex3f(-1, 1, 1);
    glVertex3f(1, 1, -1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face A, part 2
    glVertex3f(-1, 1, 1);
    glVertex3f(1, 1, -1);
    glVertex3f(1, 1, 1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face B, part 1
    glVertex3f(1, 1, -1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, -1, -1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face B, part 2
    glVertex3f(1, 1, 1);
    glVertex3f(1, -1, -1);
    glVertex3f(1, -1, 1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face C
    glVertex3f(-1, 1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(-1, -1, 1);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex3f(-1, -1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, -1, 1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face D
    glVertex3f(-1, 1, 1);
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, 1, -1);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex3f(-1, 1, 1);
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, -1, 1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face E
    glVertex3f(-1, 1, -1);
    glVertex3f(1, -1, -1);
    glVertex3f(-1, -1, -1);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex3f(-1, 1, -1);
    glVertex3f(1, -1, -1);
    glVertex3f(1, 1, -1);
    glEnd();

    glBegin(GL_TRIANGLES);
    // face F
    glVertex3f(-1, -1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, -1, -1);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex3f(-1, -1, 1);
    glVertex3f(-1, -1, -1);
    glVertex3f(1, -1, -1);
    glEnd();

    // Swap the buffers
    glutSwapBuffers();
}

void reshape(int w, int h)
{
    // Set the viewport to cover the entire window
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);

    // Set up the projection matrix
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-4.0, 4.0, -4.0, 4.0, -4.0, 4.0);

    // Switch back to modelview matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void idlefunc()
{
    // Change animation parameter
    beta += 0.05;
    if (beta > 360) beta -= 360;
    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 'b': // Yellow brass material
        glMaterialfv(GL_FRONT, GL_AMBIENT, brassAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, brassDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, brassSpecular);
        glMaterialf(GL_FRONT, GL_SHININESS, brassShininess);
        break;
    case 'n': // Red plastic material
        glMaterialfv(GL_FRONT, GL_AMBIENT, redPlasticAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, redPlasticDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, redPlasticSpecular);
        glMaterialf(GL_FRONT, GL_SHININESS, redPlasticShininess);
        break;
    case 'm': // White shiny material
        glMaterialfv(GL_FRONT, GL_AMBIENT, whiteShinyAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, whiteShinyDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, whiteShinySpecular);
        glMaterialf(GL_FRONT, GL_SHININESS, whiteShinyShininess);
        break;
    case 'o': // White light
        glLightfv(GL_LIGHT1, GL_DIFFUSE, light0Diffuse);
        glLightfv(GL_LIGHT1, GL_SPECULAR, light0Specular);
        break;
    case 'p': // Red light
        glLightfv(GL_LIGHT1, GL_DIFFUSE, light1Diffuse);
        glLightfv(GL_LIGHT1, GL_SPECULAR, light1Specular);
        break;
    case 27: // Escape key
        exit(0);
        break;
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow(argv[0]);
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idlefunc);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
