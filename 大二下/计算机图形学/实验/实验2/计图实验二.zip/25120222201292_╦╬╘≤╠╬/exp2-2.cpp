#include <GL/glut.h>
#include <cmath>

#define DEG_TO_RAD 0.017453
const GLfloat RR = 2.0; // ����뾶
GLfloat beta = 0; // ����Ƕ�
GLfloat cubeAngle = 0; // ��������ת�Ƕ�

GLfloat cameraPos[] = { 0.0, 0.0, 5.0 }; // ���λ��
GLfloat cameraFront[] = { 0.0, 0.0, -1.0 }; // ���ǰ����
GLfloat cameraUp[] = { 0.0, 1.0, 0.0 }; // ����Ϸ���

bool lockCamera = false; // ��������ƶ�����ת

void init(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glColor3f(1.0, 0.0, 0.0);
    glEnable(GL_DEPTH_TEST); // ������Ȳ���
}

void drawCube()
{
    // ����������ĸ�����
    glBegin(GL_QUADS);
    // ����
    glColor3f(1.0, 0.0, 0.0); // ��ɫ
    glVertex3f(-1, -1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(-1, 1, 1);
    // ����
    glColor3f(0.0, 1.0, 0.0); // ��ɫ
    glVertex3f(-1, -1, -1);
    glVertex3f(1, -1, -1);
    glVertex3f(1, 1, -1);
    glVertex3f(-1, 1, -1);
    // ����
    glColor3f(0.0, 0.0, 1.0); // ��ɫ
    glVertex3f(-1, 1, -1);
    glVertex3f(1, 1, -1);
    glVertex3f(1, 1, 1);
    glVertex3f(-1, 1, 1);
    // ����
    glColor3f(1.0, 1.0, 0.0); // ��ɫ
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, -1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, -1, -1);
    // ����
    glColor3f(1.0, 0.0, 1.0); // ��ɫ
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, -1, 1);
    glVertex3f(-1, 1, 1);
    glVertex3f(-1, 1, -1);
    // ����
    glColor3f(0.0, 1.0, 1.0); // ��ɫ
    glVertex3f(1, -1, -1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, 1, -1);
    glEnd();
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    if (!lockCamera)
    {
        // �������λ�úͷ���
        gluLookAt(cameraPos[0], cameraPos[1], cameraPos[2],
            cameraPos[0] + cameraFront[0], cameraPos[1] + cameraFront[1], cameraPos[2] + cameraFront[2],
            cameraUp[0], cameraUp[1], cameraUp[2]);
    }

    // ������ת��������
    glPushMatrix();
    glTranslatef(0.0, 0.0, -2.0); // ���������Ƶ�Զ�������λ��
    glRotatef(cubeAngle, 1.0, 1.0, 1.0); // �� (1,1,1) ����ת
    drawCube();
    glPopMatrix();

    glutSwapBuffers();
}

void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (GLfloat)w / (GLfloat)h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

void idlefunc()
{
    // ��ת������
    cubeAngle += 0.5;
    if (cubeAngle > 360)
        cubeAngle -= 360;

    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
    float cameraSpeed = 0.1;

    switch (key)
    {
    case 'w':
        cameraPos[0] += cameraSpeed * cameraFront[0];
        cameraPos[2] += cameraSpeed * cameraFront[2];
        break;
    case 's':
        cameraPos[0] -= cameraSpeed * cameraFront[0];
        cameraPos[2] -= cameraSpeed * cameraFront[2];
        break;
    case 'a':
        // ��˻�ȡ����
        cameraPos[0] -= cameraSpeed * (cameraFront[2]);
        cameraPos[2] += cameraSpeed * (cameraFront[0]);
        break;
    case 'd':
        // ��˻�ȡ�ҷ���
        cameraPos[0] += cameraSpeed * (cameraFront[2]);
        cameraPos[2] -= cameraSpeed * (cameraFront[0]);
        break;
    case 'q':
        cameraPos[1] += cameraSpeed;
        break;
    case 'e':
        cameraPos[1] -= cameraSpeed;
        break;
    case 'L':
        lockCamera = !lockCamera;
        break;
    case 27:
        exit(0);
        break;
    }
}

void mouse(int x, int y)
{
    static int lastX = -1;
    static int lastY = -1;

    if (lastX == -1 || lastY == -1)
    {
        lastX = x;
        lastY = y;
        return;
    }

    float sensitivity = 0.05; // ���������
    float deltaX = (x - lastX) * sensitivity;
    float deltaY = (lastY - y) * sensitivity; // y�ᷴ��

    lastX = x;
    lastY = y;

    float yaw = deltaX;
    float pitch = deltaY;

    // ��������ĳ���
    float yawRad = DEG_TO_RAD * yaw;
    float pitchRad = DEG_TO_RAD * pitch;

    GLfloat newX = cameraFront[0] * cos(yawRad) + cameraFront[2] * sin(yawRad);
    GLfloat newY = cameraFront[1];
    GLfloat newZ = -cameraFront[0] * sin(yawRad) + cameraFront[2] * cos(yawRad);
    cameraFront[0] = newX;
    cameraFront[1] = newY;
    cameraFront[2] = newZ;

    // ʹ��ŷ�������Ƹ����Ƕ�
    if ((cameraFront[1] > 0.99 && pitch > 0) || (cameraFront[1] < -0.99 && pitch < 0))
        return;

    GLfloat pitchAxis[] = { 1.0, 0.0, 0.0 }; // ��X����ת
    GLfloat newCameraFront[3];
    GLfloat c = cos(pitchRad);
    GLfloat s = sin(pitchRad);
    newCameraFront[0] = cameraFront[0] * c + (1 - c) * pitchAxis[0] + cameraFront[1] * s;
    newCameraFront[1] = cameraFront[1] * c - (1 - c) * pitchAxis[1] - cameraFront[0] * s;
    newCameraFront[2] = cameraFront[2] * c + (1 - c) * pitchAxis[2];

    // ��������ĳ���
    for (int i = 0; i < 3; ++i)
        cameraFront[i] = newCameraFront[i];

    glutPostRedisplay();
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow(argv[0]);
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idlefunc);
    glutKeyboardFunc(keyboard);
    glutPassiveMotionFunc(mouse); // ʹ����깦��
    glutMainLoop();
    return 0;
}
